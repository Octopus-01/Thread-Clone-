package com.learn.threadyt.model

data class UserModel(
    val email: String = "",
    val name: String= "",
    val username: String = "",
    val bio: String = "",
    val ImageUrl: String = "",
    val uid: String = "",
)
